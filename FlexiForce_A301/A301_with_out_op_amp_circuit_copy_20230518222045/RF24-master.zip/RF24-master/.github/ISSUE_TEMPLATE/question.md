---
name: Question
about: Have a question?
title: "[Question]"
labels: question
assignees: ''

---

Please read [about common issues](https://github.com/nRF24/RF24/blob/master/COMMON_ISSUES.md) first. It addresses the most common problems that people have (whether they know it or not).
